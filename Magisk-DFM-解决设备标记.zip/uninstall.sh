##########################################################################################
#
# priv Magisk Module Uninstaller Script
#
##########################################################################################

remove_priv_data_dir() {
  rm -rf /data/adb/Whitelist520/DFM-LING
  rm -rf /data/adb/Whitelist520/DFM-LING.pid
  chmod 700 /mnt/vendor/persist/data
}

remove_priv_data_dir
