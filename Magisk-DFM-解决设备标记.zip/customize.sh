#!/sbin/sh
#####################
# Priv Protect Customization
#####################
SKIPUNZIP=1

# 检查目标目录是否存在
if [ ! -d "/mnt/vendor/persist/data" ]; then
    ui_print "*******************************"
    ui_print "本方案不支持此设备"
    ui_print "退出安装！"
    ui_print "*******************************"
    exit 1
fi

ui_print "请注意导致掉框的因素有很多种"
ui_print "因此不是全部都一定有用！"
ui_print "多的话我不想多说，能就是能，不能就是不能"
ui_print "本模块免费交流学习使用"
ui_print "没起作用也别BB，小学生请闭嘴，我有厌蠢症"


unzip -j -o "${ZIPFILE}" 'priv/DFM/*' -d $MODPATH/DFM >&2
mkdir -p /data/adb/Whitelist520/
chmod 755 /data/adb/Whitelist520/
chown root:root /data/adb/Whitelist520/
unzip -j -o "${ZIPFILE}" 'service.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'uninstall.sh' -d $MODPATH >&2
am start -a android.intent.action.VIEW -d tg://resolve?domain=Whitelist520 >/dev/null 2>&1
# generate module.prop
ui_print "- 生成 module.prop"
rm -rf $MODPATH/module.prop
touch $MODPATH/module.prop
echo "id=DFM-LING" >$MODPATH/module.prop
echo "name=DFM-解决设备标记" >>$MODPATH/module.prop
echo "version=TG频道@Whitelist520" >>$MODPATH/module.prop
echo "versionCode=20250809" >>$MODPATH/module.prop
echo "author=阿灵" >>$MODPATH/module.prop
echo "description=解决DFM设备标记导致掉框问题，请注意导致掉框的因素有很多种，因此不是全部都能解决！多的话我不想多说，能就是能，不能就是不能，没起作用也别BB，小学生请闭嘴，我有厌蠢症" >>$MODPATH/module.prop

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/DFM/start.sh 0 0 0777